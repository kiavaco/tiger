bot_token = "654606653:AAGGhkfrJa7HLbM24_KgiFGP4QaVfUQIW8A" -- توکن رباتُ
channel_username = '@TiiGeRTeaM' -- آیدی کانال
channel_inline = 'TiiGeRTeaM' -- آیدی کانال بدون @
sudo_username = '@Arashwm' -- آیدی سازنده ربات
gp_sudo = -1001216848131 -- آیدی گروه سودو ها
SUDO = 205549111 -- آیدی سودو اصلی
BotTiiGeR_id = 355523548 --آیدی ربات cli
BotTiiGeR_idapi = 654606653 --آیدی ربات api
RedisIndex = '1' -- شماره ردیس
EndPm = " ツ"

--[[
opened By @Arashwm AND @Arashwm
My Channel @Arashwm & @TiiGeRTaeM
]]--
